package com.example.testvbar;

import com.example.testvbar.R;
import com.vguang.VbarSo;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.os.Handler;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {

	private TextView decodeStr;
	private Button opendev, beep1, beep2, lignton, lightoff, close,
			decodestart, closedev;

	boolean state = false;
	boolean devicestate = false;

	int vbar_channel = 0;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		decodeStr = (TextView) findViewById(R.id.decodeStr);
		decodeStr.setMovementMethod(ScrollingMovementMethod.getInstance());
		beep1 = (Button) findViewById(R.id.beep1);
		beep1.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				vbarBeep(true);

			}
		});

		beep2 = (Button) findViewById(R.id.beep2);
		beep2.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				vbarBeep(false);

			}
		});

		lignton = (Button) findViewById(R.id.lighton);
		lignton.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				vbarLight(true);

			}
		});

		close = (Button) findViewById(R.id.close);
		close.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				System.exit(0);
			}
		});
		lightoff = (Button) findViewById(R.id.lightoff);
		lightoff.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				vbarLight(false);

			}
		});
		opendev = (Button) findViewById(R.id.openDev);
		opendev.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				new Thread() {
					@Override
					public void run() {
						// TODO Auto-generated method stub
						vbar_channel = VbarSo.vbar_channel_open(1,
								"hidraw1".getBytes());
						handler.sendEmptyMessage(vbar_channel!=0?0x01:0x0);
					}
				}.start();
			}
		});

		decodestart = (Button) findViewById(R.id.begindecode);
		decodestart.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Thread t = new Thread() {
					@Override
					public void run() {
						// TODO Auto-generated method stub
						super.run();
						while (devicestate) {
							final String str = getResultsingle();
							if (str != null) {
								runOnUiThread(new Runnable() {
									public void run() {
										{
											decodeStr.setText(str + "\r\n");
										}
									}
								});

							}
							try {
								Thread.sleep(0);
							} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
					}
				};
				t.start();
				if (devicestate) {
					beep1.setEnabled(false);
					lignton.setEnabled(false);
					lightoff.setEnabled(false);

				}

			}
		});
	}

	Handler handler=new Handler(){
		public void handleMessage(android.os.Message msg){
			if(msg.what==0x01){
				AlertDialog.Builder builders  = new AlertDialog.Builder(MainActivity.this);
				builders.setTitle("设备连接状态" ) ;
				builders.setMessage("连接成功" ) ;
				builders.setPositiveButton("确认" , null );
				builders.show();
				Log.v("######################", "open success");
				devicestate = true;
				beep1.setEnabled(true);
				lignton.setEnabled(true);
				lightoff.setEnabled(true);

			} else {
				AlertDialog.Builder builder  = new AlertDialog.Builder(MainActivity.this);
				builder.setTitle("设备连接状态" ) ;
				builder.setMessage("连接失败" ) ;
				builder.setPositiveButton("确认" , null );
				builder.show();
				devicestate = false;
				Log.v("#####################", "open fail");
			}
		}};
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	// 打开设备
	public boolean vbarOpen() {
		if (vbar_channel == 0) {
			vbar_channel = VbarSo
					.vbar_channel_open(1, "11vbar open".getBytes());
		}
		if (vbar_channel != 0) {
			System.out.println("open device success");
			return true;
		} else {
			System.out.println("open device fail");
			return false;
		}
	}
	// 背光控制
	public void vbarLight(boolean lightstate) {
		byte[] buffer = new byte[1024];
		byte[] buffer1 = new byte[1024];
		int i = 0;
		if (lightstate) {
			buffer[i] = 0x55;
			buffer[++i] = (byte) 0xAA;
			buffer[++i] = 0x24;
			buffer[++i] = 0x01;
			buffer[++i] = 0x00;
			buffer[++i] = 0x01;
			buffer[++i] = (byte) 0xDB;
			int sendreturn = VbarSo.vbar_channel_send(vbar_channel, buffer,
					1024);
			VbarSo.vbar_channel_recv(vbar_channel, buffer1, 1024, 200);
		} else {
			buffer[i] = 0x55;
			buffer[++i] = (byte) 0xAA;
			buffer[++i] = 0x24;
			buffer[++i] = 0x01;
			buffer[++i] = 0x00;
			buffer[++i] = 0x00;
			buffer[++i] = (byte) 0xDA;

			VbarSo.vbar_channel_send(vbar_channel, buffer, 1024);
			VbarSo.vbar_channel_recv(vbar_channel, buffer1, 1024, 200);
		}
	}

	// 扫码蜂鸣器开关设置
	public void vbarBeep(boolean state) {
		byte[] buffer = new byte[1024];
		byte[] buffer1 = new byte[1024];
		int i = 0;
		if (state) {
			buffer[i] = 0x55;
			buffer[++i] = (byte) 0xAA;
			buffer[++i] = (byte) 0x25;
			buffer[++i] = 0x01;
			buffer[++i] = 0x00;
			buffer[++i] = 0x01;
			buffer[++i] = (byte) 0xDA;
			int beep1state = VbarSo.vbar_channel_send(vbar_channel, buffer,
					1024);
			VbarSo.vbar_channel_recv(vbar_channel, buffer, 1024, 200);
		} else {

			buffer[i] = 0x55;
			buffer[++i] = (byte) 0xAA;
			buffer[++i] = 0x25;
			buffer[++i] = 0x01;
			buffer[++i] = 0x00;
			buffer[++i] = 0x00;
			buffer[++i] = (byte) 0xDB;
			VbarSo.vbar_channel_send(vbar_channel, buffer, 1024);
			VbarSo.vbar_channel_recv(vbar_channel, buffer1, 1024, 200);
		}
	}
	//扫码开关
	public void vbarScanswitch(boolean state) {
		byte[] buffer = new byte[1024];
		byte[] buffer1 = new byte[1024];
		int i = 0;
		if (state) {
			buffer[i] = 0x55;
			buffer[++i] = (byte) 0xAA;
			buffer[++i] = (byte) 0x05;
			buffer[++i] = 0x01;
			buffer[++i] = 0x00;
			buffer[++i] = 0x00;
			buffer[++i] = (byte) 0xFB;
			int beep1state = VbarSo.vbar_channel_send(vbar_channel, buffer,
					1024);
			VbarSo.vbar_channel_recv(vbar_channel, buffer, 1024, 200);
		} else {

			buffer[i] = 0x55;
			buffer[++i] = (byte) 0xAA;
			buffer[++i] = 0x05;
			buffer[++i] = 0x01;
			buffer[++i] = 0x00;
			buffer[++i] = 0x01;
			buffer[++i] = (byte) 0xFA;
			VbarSo.vbar_channel_send(vbar_channel, buffer, 1024);
			VbarSo.vbar_channel_recv(vbar_channel, buffer1, 1024, 200);
		}
	}

	// 接收结果
	public String getResultsingle() {
		byte[] bufferrecv = new byte[1024];
		VbarSo.vbar_channel_recv(vbar_channel, bufferrecv, 1024, 200);
		if (bufferrecv[0] == 85 && bufferrecv[1] == -86
				&& bufferrecv[3] == 0x00) {
			int datalen = (bufferrecv[4] & 0xff)
					+ ((bufferrecv[5] << 8) & 0xff); // 高位左移位8位 按协议低位在前 高位在后
			// 扫码数据总长度
			if (datalen > 0) {
				byte[] readBuffers = new byte[datalen];
				for (int s1 = 0; s1 < datalen; s1++) {
					readBuffers[s1] = bufferrecv[6 + s1];
				}
				String str = new String(readBuffers);
				System.out.println("str=======" + str);
				return str;
			} else {
				return "";
			}
		} else {
			return "";
		}
	}
}
