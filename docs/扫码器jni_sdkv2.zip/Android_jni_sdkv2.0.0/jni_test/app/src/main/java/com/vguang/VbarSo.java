package com.vguang;

/**
 * libvbar.so java
 * @author yuxd
 *
 */
public class VbarSo {
	static
	{

		System.loadLibrary("vbar");
	}

	/**
	 *
	 * @param type
	 * @param arg
	 * @return
	 */
	public native static int vbar_channel_open(int type, byte[] arg);
	
	/**
	 *
	 * @param channel
	 * @param buffer
	 * @param length
	 * @return
	 */
	public native static int vbar_channel_send(int channel, byte[] buffer, int length);
	
	/**
	 *
	 * @param channel
	 * @param buffer
	 * @param size
	 * @param milliseconds
	 * @return
	 */
	public native static int vbar_channel_recv(int channel, byte[] buffer, int size, int milliseconds);
	
	/**
	 *
	 * @param channel
	 */
	public native static void vbar_channel_close(int channel);
}
