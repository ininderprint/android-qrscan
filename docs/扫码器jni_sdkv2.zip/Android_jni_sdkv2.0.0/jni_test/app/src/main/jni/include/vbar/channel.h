#ifndef __VBAR_CHANNEL_H__
#define __VBAR_CHANNEL_H__

#include "vbar/export.h" /* for VBARLIB_API */
struct vbar_channel;

#ifdef	__cplusplus
extern "C" {
#endif

VBARLIB_API struct vbar_channel *vbar_channel_open(int type, unsigned long arg);

VBARLIB_API int vbar_channel_send(struct vbar_channel *channel,
                                  const unsigned char *buffer, size_t length);

VBARLIB_API int vbar_channel_recv(struct vbar_channel *channel,
                                  unsigned char *buffer, size_t size, int milliseconds);

VBARLIB_API void vbar_channel_close(struct vbar_channel *channel);

#ifdef __cplusplus
}
#endif

#endif /* __VBAR_CHANNEL_H__ */
