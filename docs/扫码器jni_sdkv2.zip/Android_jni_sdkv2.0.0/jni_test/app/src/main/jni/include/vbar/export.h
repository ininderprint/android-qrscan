#ifndef __VBAR_EXPORT_H__
#define __VBAR_EXPORT_H__

/* bool类型支持 */
#include <stdbool.h>

#ifdef _MSC_VER
/* on MS environments, the inline keyword is available in C++ only */
#if !defined(__cplusplus)
#define inline __inline
#endif
/* ssize_t is also not available (copy/paste from MinGW) */
#ifndef _SSIZE_T_DEFINED
#define _SSIZE_T_DEFINED
#undef ssize_t
#ifdef _WIN64
  typedef __int64 ssize_t;
#else
  typedef int ssize_t;
#endif /* _WIN64 */
#endif /* _SSIZE_T_DEFINED */
#endif /* _MSC_VER */

/* stdint.h is not available on older MSVC */
#if defined(_MSC_VER) && (_MSC_VER < 1600) && (!defined(_STDINT)) && (!defined(_STDINT_H))
typedef unsigned __int8   uint8_t;
typedef unsigned __int16  uint16_t;
typedef unsigned __int32  uint32_t;
#else
#include <stdint.h>
#endif

#if !defined(_WIN32_WCE)
#include <sys/types.h>
#endif


/* 动态导出函数的声明宏 */
#ifdef VBAR_BUILD_AS_DLL
#   if defined(_WIN32) || defined(_WIN64)
#       ifdef VBAR_LIB
#           define VBARLIB_API __declspec(dllexport)
#       else
#           define VBARLIB_API __declspec(dllimport)
#       endif
#   elif defined(__GNUC__) && defined(__linux__)
#       ifdef VBAR_LIB
#           define VBARLIB_API __attribute__((visibility("default")))
#       else
#           define VBARLIB_API
#       endif
#   else
#       error "不支持的操作系统"
#   endif
#else
#   define VBARLIB_API
#endif /* VBAR_BUILD_AS_DLL */

#endif /* __VBAR_EXPORT_H__ */
