﻿#include "vbar/channel.h"

#include <stdlib.h>
#include <stdio.h>

#include <android/log.h>

#define  LOG_TAG    "Vguang"
#define  LOGI(...)  __android_log_print(ANDROID_LOG_INFO,LOG_TAG,__VA_ARGS__)
#define  LOGE(...)  __android_log_print(ANDROID_LOG_ERROR,LOG_TAG,__VA_ARGS__)

/* vbar抽象结构定义(支持运行期类型识别及引用计数) */
struct vbar_object {
    short type;                 /* 对象类型 */
    short count;                /* 引用计数 */
    void (*release)(void *);    /* 释放函数 */
};

/* 链路层信道结构定义 */
struct vbar_channel {
    struct vbar_object object;
    int (*send)(struct vbar_channel *channel, const unsigned char *buffer, size_t size);
    int (*recv)(struct vbar_channel *channel, unsigned char *buffer, size_t size, int mills);
    void *private_data;
};


VBARLIB_API struct vbar_channel *vbar_channel_open(int type, unsigned long arg)
{
	struct vbar_channel *pchannel = (struct vbar_channel *)malloc(sizeof(struct vbar_channel));
	unsigned char* pstr = (unsigned char*)arg;
	LOGI("vbar_channel_open type:%d arg:%s", type, (char *)arg);
	return pchannel;
}

VBARLIB_API int vbar_channel_send(struct vbar_channel *channel,
                                  const unsigned char *buffer, size_t length)
{

	LOGI("vbar_channel_send buffer:%s length:%d", (char *)buffer, length);

	return 1;
}

VBARLIB_API int vbar_channel_recv(struct vbar_channel *channel,
                                  unsigned char *buffer, size_t size, int milliseconds)
{
	LOGI("vbar_channel_recv size:%d milliseconds:%d", size, milliseconds);

	memset(buffer, 0, size);
	sprintf(buffer, "%s", "inc!");

	return 1;
}

VBARLIB_API void vbar_channel_close(struct vbar_channel *channel)
{
	LOGI("vbar_channel_close");

	return;
}

